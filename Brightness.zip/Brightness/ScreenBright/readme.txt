
ScreenBright for Windows 2000, XP, Vista, 7
Copyright � 2006-2013 Berthold Jaksch
www.screenwhite.com
info@screenwhite.com


Requirements
------------

for Windows 2000, XP:
a DDC/CI compatible screen and elder graphics from Ati, Intel or Nvidia
or a USB control compatible screen

for Windows Vista, 7:
a DDC/CI compatible screen and a WDDM graphics driver
or a USB control compatible screen


Command Line Use
----------------

Apart from using the graphical user interface, you can use command line 
arguments to modify the settings of your screen.

WARNING: You can turn your screen completely black if you use wrong command 
line arguments! The graphical user interface prevents you from turning the 
contrast or all color values to 0.

ScreenBright must be closed before starting it with command line arguments.

ScreenBright -get <setting> shows the current, minimum and maximum values 
of <setting>.
ScreenBright -set <setting> <value> sets <setting> to <value>.
<setting> can be "brightness", "contrast", "red", "green", "blue" or "save". 
Omit <value> in case of "save". Furtermore <setting> can be a virtual control 
panel code in hexadezimal form like 0x14. You can use multiple pairs of 
<setting> and <value> in one command line. The settings are applied from the 
left to the right. To swith to a different screen than the first one for the 
following settings use "screen" as <setting> and the number of the screen as 
<value>.


Warning
-------

The memory for screen settings, usually EEPROM, can only be written a limited
number of times. For example, some EEPROMs can last 1000000 writes.
